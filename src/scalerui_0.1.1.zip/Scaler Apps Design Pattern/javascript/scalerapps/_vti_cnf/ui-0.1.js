vti_encoding:SR|utf8-nl
vti_author:SR|Simon-PC\\Simon
vti_modifiedby:SR|Simon-PC\\Simon
vti_timelastmodified:TR|05 Nov 2009 04:15:29 -0000
vti_timecreated:TR|02 Nov 2009 00:02:22 -0000
vti_title:SR|Untitled 1
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|default.html
vti_nexttolasttimemodified:TW|04 Nov 2009 05:46:06 -0000
vti_cacheddtm:TX|05 Nov 2009 04:15:29 -0000
vti_filesize:IR|4849
