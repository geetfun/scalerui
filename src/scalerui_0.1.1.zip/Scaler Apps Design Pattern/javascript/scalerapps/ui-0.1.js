﻿/* 
	---------- Scaler Apps UI Components ----------  

	Version: 0.1 (unreleased)

	(c) Copyright 2009   Simon Chiu

	Scaler Apps     http://www.scalerapps.com

	E-mail: contact@scalerapps.com
	
	MIT License
	
*/
$.scalerapps = {};

var Page = {
	initialize: function() {
		$.scalerapps.body = $("body");
		$.scalerapps.sidebar = $("#sidebar");
		$.scalerapps.main = $("#main");
	}
};

var Sidebar = {
	// Sets the appropriate variables
	initialize: function() {
		if ($.scalerapps.body.hasClass("expanded")) {
			var togglerArrow = "&#171;";
		} else {
			var togglerArrow = "&#187;";
		};
				
		$("#sidebarToggler").html(togglerArrow );
	},
	
	minimize: function() {
		$.scalerapps.body.removeClass("expanded").addClass("minimized");
		$("#sidebarToggler").html("&#187;");
	},
	
	maximize: function() {
		$.scalerapps.body.removeClass("minimized").addClass("expanded");
		$("#sidebarToggler").html("&#171;");
	},
	
	sectionToggle: function(section) {
		var $section = $(section);
		var $subsection = $section.find("ul");
		if ($subsection .is(":visible")) {
			//$subsection.slideUp("fast");
			$subsection.hide();
		} else {
			//$subsection.slideDown("fast");
			$subsection.show();
		};		
	},
		
	// Use this function if you want to disable the sidebar altogether
	disable: function() {
	
	}
};

var TableList = {
	initialize: function() {
	
		// For mass toggling of checkboxes based on form
		var checkboxes = {
			activate: function(form) { form.find("input:checkbox").each(function() { this.checked = true }); },
			deactivate: function(form) { form.find("input:checkbox").each(function() { this.checked = false }); },
			highlight: function(form) {
				form.find("tbody input:checkbox").each(function() {
					if (this.checked==true) { $(this).closest("tr").addClass("selected"); }
					else { $(this).closest("tr").removeClass("selected"); };
				});
			},
			refresh: function(form) {
				var number_of_checkboxes = form.find("tbody input:checkbox").size();
				var number_of_checked = form.find("tbody input:checkbox[checked=true]").size();
				var toggler = form.find("thead input.toggler")[0];
				
				// This keeps the toggler checkbox in sync with the rest of the checkboxes
				if (number_of_checkboxes == number_of_checked) {
					toggler.checked = true;
				} else {
					toggler.checked = false;
				};
			}
		};
		
		// Highlights all the checkboxes that are checked from refreshes
		$("form table.list").each(function() {
			var $form = $(this).closest("form");
			checkboxes.highlight($form);
			checkboxes.refresh($form);
		});
	
		// Actual trigger for checkbox toggling
		$("form table.list").click(function(e) {
			var $target = $(e.target);
			var $form = $target.closest("form");
			
			// Mass toggling
			if ($target.is("thead input.toggler:checkbox")) {
				if ($target.attr("checked")==true) { checkboxes.activate($form); }
				else { checkboxes.deactivate($form);	}
			};
						
			// Mass toggling links at tfoot
			if ($target.is("tfoot a:contains('Select All')")) { checkboxes.activate($form); checkboxes.highlight($form); return false; };
			if ($target.is("tfoot a:contains('None')")) { checkboxes.deactivate($form); checkboxes.highlight($form); return false; };

			// Refreshes highlighted rows & syncs toggler w/ checkboxes
			if ($target.is("input:checkbox")) { 
				checkboxes.highlight($form); 
				checkboxes.refresh($form);
			};
			
		});
	}
};

var TableForm = {
	initialize: function() {
		$("table.form tbody input, form table.form tbody select, form table.form tbody textarea, form table.form tbody a").focus(function() {
			$(this).closest("tr").addClass("active");
		}).blur(function() {
			$(this).closest("tr").removeClass("active");		
		});
		
		$("input[type=text][data-sync]").keyup(function() {
			var header = $(this).attr("data-sync");
			var $header = $(header);
			var inputValue = $(this).val();
			
			// Stores the original value
			if (!$header.data("originalValue")) { $header.data("originalValue", $header.html()); };
			
			if (inputValue.length == 0) {
				$header.html($header.data("originalValue"));
			} else {
				$header.html(inputValue);
			};
		});
	}
};

$(document).ready(function() {
	Page.initialize();
	Sidebar.initialize();
	TableList.initialize();
	TableForm.initialize();
			
	$.scalerapps.sidebar.live("click", function(e) {
		var $target = $(e.target);
		
		if ($target.is("#sidebarToggler")) {
			if ($.scalerapps.body.hasClass("expanded")) {
				Sidebar.minimize();
			} else {
				Sidebar.maximize();
			};
			return false;
		};
		
		if ($target.is("#leftNav > li *")) {
			var section = $target.parents("li");
			Sidebar.sectionToggle(section);
			return false;
		};
	});

});